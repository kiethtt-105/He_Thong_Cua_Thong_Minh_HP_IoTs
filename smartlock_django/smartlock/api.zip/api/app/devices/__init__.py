"""Khoá + lệnh điều khiển."""
